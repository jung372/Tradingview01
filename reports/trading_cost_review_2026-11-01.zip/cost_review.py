"""python cost_review.py (NumPy). Outputs cost_results.json."""
import json
import numpy as np
from methods import get, signals, more_signals, run, dt, root
INITIAL_KRW=100_000_000
def evaluate(ds,px,fx,targets,key,rates):
    n=len(rates); rate=np.array(rates)[:,None]
    h=targets[0][None,:]/(1+rate*targets[0].sum())
    paid=h.sum(1)*rate[:,0]; cash=1-h.sum(1)-paid
    fees=paid.copy(); orders=np.zeros(n,int); events=np.zeros(n,int)
    peak=np.ones((n,2)); dd=np.zeros((n,2))
    for j in range(1,len(ds)):
        t=targets[j]
        quarter=(ds[j-1].month-1)//3!=(ds[j].month-1)//3
        flag=(np.max(abs(h/(h.sum(1)+cash)[:,None]-t),axis=1)>=.05-1e-12)&quarter
        if np.any(t!=targets[j-1]):flag[:]=True
        if key=='hold':flag[:]=False
        if key=='quarter':flag[:]=quarter
        h*=px[j]/px[j-1]
        if flag.any():
            before=h[flag]; gross=(before.sum(1)+cash[flag])[:,None]; net=gross
            for _ in range(7):net=gross-rate[flag]*abs(net*t-before).sum(1)[:,None]
            tr=abs(net*t-before); charge=tr.sum(1)*rate[flag,0]
            fees[flag]+=charge*fx[j]/fx[0]
            orders[flag]+=(tr>1e-10).sum(1);events[flag]+=1
            h[flag]=net*t;cash[flag]=net[:,0]*(1-t.sum())
            assert np.allclose(net[:,0]+charge,gross[:,0])
        usd=h.sum(1)+cash
        wealth=np.column_stack((usd*fx[j]/fx[0],usd));peak=np.maximum(peak,wealth)
        dd=np.minimum(dd,wealth/peak-1)
    annual=(wealth**(365.2425/(ds[-1]-ds[0]).days)-1)*100
    return [dict(rate=r,KRW_CAGR=v[0],USD_CAGR=v[1],KRW_MDD=d[0]*100,USD_MDD=d[1]*100,
                 end_KRW=round(end[0]*INITIAL_KRW),fees_KRW=round(f*INITIAL_KRW),orders=int(o),events=int(e))
            for r,v,d,end,f,o,e in zip(rates,annual,dd,wealth,fees,orders,events)]
out=[]
rates=[0,.0005,.001,.0015,.0018,.0019,.002,.0025,.005]
for name in ['DVY','VIG']:
    data=get(name);ds,p,fx=data;targets=signals(data,name)|more_signals(data,name)
    for group,start in [('full',0),('later',ds.index(dt.date(2016,10,31))),('exact',ds.index(dt.date(2021,7,1)))]:
        for key,t in targets.items():
            rows=evaluate(ds[start:],p[start:],fx[start:],t[start:],key,rates)
            ref,_=run(data,t,start,len(ds)-1,.001,key)
            assert np.allclose([rows[2][k] for k in ['KRW_CAGR','KRW_MDD','USD_CAGR','USD_MDD']],ref[:4])
            for row in rows:out.append(dict(proxy=name,segment=group,strategy=key,**row))
            if group=='full':
                print(name,key,'CAGR 0/5/10/15/18/19/20/25/50bp',*[round(x['KRW_CAGR'],4) for x in rows], 'MDD/fees/terminal_gap/orders/events@10bp', round(rows[2]['KRW_MDD'],3),rows[2]['fees_KRW'],rows[0]['end_KRW']-rows[2]['end_KRW'],rows[2]['orders'],rows[2]['events'])
(root/'cost_results.json').write_text(json.dumps(out,indent=1))

