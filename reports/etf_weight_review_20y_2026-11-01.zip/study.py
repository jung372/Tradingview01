"""Run beside the nine Yahoo Finance daily chart JSON files. Requires Python 3 and numpy."""
import json, zipfile, pathlib, datetime as dt, bisect
import numpy as np
root=pathlib.Path(__file__).parent

def prices(t):
    r=json.loads((root/(t+'.json')).read_bytes())['chart']['result'][0]
    return {(dt.datetime.fromtimestamp(ts,dt.timezone.utc)+dt.timedelta(hours=12 if t=='KRW=X' else 0)).date():v for ts,v in zip(r['timestamp'],r['indicators']['adjclose'][0]['adjclose']) if v and v>0}
w=np.array([(a,b,c,20-a-b-c) for a in range(21) for b in range(21-a) for c in range(21-a-b)],float)/20
def idx(v):return np.flatnonzero(np.all(np.isclose(w,v),axis=1))[0]
base=idx([.25,.25,.30,.20])
div=(w.min(1)>=.10)&(w.max(1)<=.40)&(w[:,3]<=.25)&(w[:,:2].sum(1)<=.700000001)
def data(names):
    p=[prices(t) for t in names]; fx=prices('KRW=X'); keys=sorted(fx)
    d=sorted(t for t in set.intersection(*(set(a) for a in p)) if dt.date(2011,10,30)<=t<=dt.date(2026,10,30))
    f=[]
    for t in d:
        k=keys[bisect.bisect_right(keys,t)-1]; assert (t-k).days<=5
        f.append(fx[k])
    return d,np.array([[a[t] for a in p] for t in d]),np.array(f)
def sim(data,start=0,stop=None,ww=w,cost=.001):
    ds,p,f=[x[start:stop] for x in data]
    val=ww.copy()/(1+cost); U=np.empty((len(ds),len(ww))); U[0]=1
    events=np.zeros(len(ww),int); orders=events.copy()
    for i in range(1,len(ds)):
        quarterly=(ds[i-1].month-1)//3!=(ds[i].month-1)//3
        if quarterly: tr=np.max(abs(val/val.sum(1)[:,None]-ww),axis=1)>=.05-1e-12
        val*=p[i]/p[i-1]
        if quarterly and tr.any():
            pre=val[tr]; wt=ww[tr]; gross=pre.sum(1)[:,None]; net=gross
            for _ in range(6):net=gross-cost*abs(net*wt-pre).sum(1)[:,None]
            val[tr]=net*wt;events[tr]+=1;orders[tr]+=(abs(net*wt-pre)>1e-10).sum(1)
        U[i]=val.sum(1)
    K=U*(f/f[0])[:,None]
    def calc(P):
        return (P[-1]**(365.2425/(ds[-1]-ds[0]).days)-1)*100,(P/np.maximum.accumulate(P,axis=0)-1).min(0)*100
    return (*calc(U),*calc(K),events,orders,U,K,ds)
def pick(s,kr=3,us=5,eq=.70):
    eligible=div&(w[:,:2].sum(1)<=eq+1e-9)&(s[3]>=s[3][base]-kr)&(s[1]>=s[1][base]-us)
    return np.flatnonzero(eligible)[s[2][eligible].argmax()]
def label(j):return '/'.join(map(str,np.rint(w[j]*100).astype(int)))
def describe(s,j):
    path=s[7][:,j]; ds=s[8]; b=(path/np.maximum.accumulate(path)).argmin(); a=path[:b+1].argmax(); hit=np.flatnonzero(path[b:]>=path[a])
    return label(j),*(round(float(t[j]),2) for t in s[:4]),int(s[4][j]),int(s[5][j]),str(ds[a]),str(ds[b]),str(ds[b+hit[0]]) if len(hit) else 'unrecovered'
def splice(proxy, actual):
    old, new = prices(proxy), prices(actual)
    first = min(new)
    assert first in old
    scale = new[first]/old[first]
    return {**{d:v*scale for d,v in old.items() if d<first}, **new}
def get(dividend):
    p=[splice(dividend,'SCHD'),splice('QQQ','QQQM'),prices('IEF'),splice('IAU','IAUM')]
    ds=sorted(d for d in set.intersection(*(set(x) for x in p)) if dt.date(2006,10,30)<=d<=dt.date(2026,10,30))
    fx=prices('KRW=X')
    import csv
    with (root/'DEXKOUS.csv').open() as fh:
        fred={dt.date.fromisoformat(x['observation_date']):float(x['DEXKOUS']) for x in csv.DictReader(fh) if x['DEXKOUS'] not in ('','.')}
    fill=[d for d in ds if d not in fx and d in fred]
    print('Missing Yahoo FX dates filled with FRED:',len(fill),fill[:3])
    fx={**fred,**fx};keys=sorted(fx); vals=[]
    for d in ds:
        day=keys[bisect.bisect_right(keys,d)-1]
        assert (d-day).days<=5
        vals.append(fx[day])
    assert ds==sorted(d for d in prices('IEF') if ds[0]<=d<=ds[-1])
    return ds,np.array([[a[d] for a in p] for d in ds]),np.array(vals)
def robust(sims,kr=3,us=5,cap=.70):
    ok=div&(w[:,:2].sum(1)<=cap+1e-9)
    for s in sims:ok&=(s[3]>=s[3][base]-kr)&(s[1]>=s[1][base]-us)
    ks=np.flatnonzero(ok)
    return ks[np.minimum.reduce([s[2] for s in sims])[ks].argmax()],len(ks)
def draw(path,ds,start,end):
    pos=[i for i,d in enumerate(ds) if start<=d.year<=end]
    z=path[pos]; b=np.argmin(z/np.maximum.accumulate(z)); a=z[:b+1].argmax()
    ia=pos[a]; ib=pos[b]; hit=np.flatnonzero(path[ib:]>=path[ia])
    return round(float((z[b]/z[a]-1)*100),2),str(ds[ia]),str(ds[ib]),str(ds[ib+hit[0]]) if len(hit) else 'unrecovered'
datasets=[get(t) for t in ['DVY','VIG']]
ds=datasets[0][0]; assert ds==datasets[1][0]
runs=[sim(t) for t in datasets]
best,n=robust(runs); old=idx([.3,.4,.2,.1]); alt=robust(runs,cap=.65)[0]
print('Dates, sessions, grids, eligible:',ds[0],ds[-1],len(ds),len(w),n)
print('selected / 65 cap / zero extra MDD / loose:',*[label(i) for i in [best,alt,robust(runs,0,0)[0],robust(runs,6,10)[0]]])
for name,s in zip(['DVY','VIG'],runs):
    print(name,'single-proxy selected',label(robust([s])[0]),'unrestricted',describe(s,s[2].argmax()))
    for k in dict.fromkeys([base,old,best,alt]):
        print('USD CAGR/MDD KRW CAGR/MDD events/orders KRW peak/trough/recovery:',describe(s,k))
        print('2007-09 USD and KRW peak-to-trough, then recovery',*[draw(path[:,k],ds,2007,2009) for path in s[6:8]])
        for yr in (2008,2022):
            ix=[i for i,d in enumerate(ds) if d.year==yr]
            print(yr,'USD/KRW calendar return',*[round(float((path[ix[-1],k]/path[ix[0]-1,k]-1)*100),2) for path in s[6:8]])
ends={y:max(i for i,t in enumerate(ds) if t.year==y and t.month==10) for y in range(2006,2027)}
forwards=[]
for yr in range(2011,2026):
    train=[sim(t,ends[yr-5],ends[yr]+1) for t in datasets]; k,_=robust(train)
    test=sim(datasets[0],ends[yr],ends[yr+1]+1,ww=w[[base,k]])
    forwards.append(test[7][-1]);print('Forward',yr,label(k),np.round((test[7][-1]-1)*100,2))
f=np.array(forwards); print('Forward geometric mean and wins',np.round((np.prod(f,axis=0)**(1/len(f))-1)*100,2),(f[:,1]>f[:,0]).sum(),len(f))
assert np.allclose(w.sum(axis=1),1)


allowed=div.copy()
for s in runs:allowed&=(s[3]>=s[3][base]-3)&(s[1]>=s[1][base]-5)
score=np.minimum(runs[0][2],runs[1][2])
for k in np.flatnonzero(allowed)[np.argsort(score[allowed])[-4:][::-1]]:
    print('nearby',label(k),round(score[k],3))
i=ds.index(min(prices('IAUM')))
short=sim(datasets[0],i,ww=w[[base,old,best]])
print('Exact period',ds[i],np.round(short[:4],2))
