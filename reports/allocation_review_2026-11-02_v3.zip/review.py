import sys,json,pathlib,datetime as dt, numpy as np
ROOT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'selective_vs_whole_rebalance_2026-11-02'))
import selective_review as old
W=np.array([(a,b,c,100-a-b-c) for a in range(10,51,5) for b in range(10,51,5) for c in range(10,51,5) if 10<=100-a-b-c<=30 and a+b<=70],float)/100
BASE=np.flatnonzero(np.all(np.isclose(W,[.15,.4,.25,.2]),axis=1))[0]
def sim(data,w,mode='whole',fee=.001,band=.05,freq=3):
 ds,p,raw,fx=data;n=len(w);v=1e8/fx[0]*w/(1+fee);basis=v*fx[0]*(1+fee);cash=np.zeros(n)
 gains={y:np.zeros(n) for y in range(ds[0].year-1,ds[-1].year+1)};paid=set();tax=lambda g:np.maximum(0,g-2500000)*.22
 peak=np.full(n,1e8);mdd=np.zeros(n);up=peak/fx[0];umdd=np.zeros(n);orders=np.zeros(n,int);paths=[peak.copy()];cashsum=np.zeros(n)
 for i in range(1,len(ds)):
  d,prev=ds[i],ds[i-1];check=(d.year,(d.month-1)//freq)!=(prev.year,(prev.month-1)//freq)
  mask=abs(v/(v.sum(1)+cash)[:,None]-w)>=band-1e-12;reb=mask.any(1)&check if mode!='hold' else np.zeros(n,bool)
  ret=p[i]/p[i-1];extra=ret-raw[i]/raw[i-1];basis+=v*np.where(extra>1e-5,extra,0)*fx[i];v=v*ret
  if d.month==5 and prev.month!=5:cash-=tax(gains[d.year-1])/fx[i];paid.add(d.year-1)
  ov=v.copy();fund=cash< -1e-8
  if fund.any():
   need=-cash[fund]/(1-fee);v[fund]*=(1-need/v[fund].sum(1))[:,None];cash[fund]+=need*(1-fee)
  ids=np.flatnonzero(reb&~fund)
  if len(ids):
   x=v[ids];wt=w[ids];c=cash[ids];gross=x.sum(1)+c;net=gross.copy()
   if mode=='whole':
    for _ in range(8):net=gross-fee*abs(wt*net[:,None]-x).sum(1)
    v[ids]=wt*net[:,None];cash[ids]=net-v[ids].sum(1)
   else:
    for _ in range(12):
     desired=np.where(mask[ids],wt*net[:,None],x);sell=np.maximum(x-desired,0);buy=np.maximum(desired-x,0)
     available=np.maximum(0,c+sell.sum(1)*(1-fee));den=buy.sum(1)*(1+fee)
     scale=np.minimum(1,np.divide(available,den,out=np.ones_like(den),where=den>0));buy*=scale[:,None];net=gross-fee*(sell.sum(1)+buy.sum(1))
    v[ids]=x-sell+buy;cash[ids]=c+sell.sum(1)*(1-fee)-buy.sum(1)*(1+fee)
  delta=v-ov;sell=np.maximum(-delta,0);buy=np.maximum(delta,0);soldbasis=basis*np.divide(sell,ov,out=np.zeros_like(ov),where=ov>0)
  gains[d.year]+=(sell*fx[i]*(1-fee)-soldbasis).sum(1);basis+=buy*fx[i]*(1+fee)-soldbasis;orders+=(abs(delta)>1e-6).sum(1)
  liability=tax(gains[d.year])+(0 if d.year-1 in paid else tax(gains[d.year-1]));nav=(v.sum(1)+cash)*fx[i]-liability
  peak=np.maximum(peak,nav);mdd=np.minimum(mdd,nav/peak-1);usd=nav/fx[i];up=np.maximum(up,usd);umdd=np.minimum(umdd,usd/up-1);paths.append(nav.copy());cashsum+=cash/(cash+v.sum(1))
  assert cash.min()>-1e-5 and v.min()>=0
 years=(ds[-1]-ds[0]).days/365.2425
 return dict(cagr=((nav/1e8)**(1/years)-1)*100,mdd=mdd*100,usd_mdd=umdd*100,orders=orders,end=nav,cash=cashsum/len(ds)*100,path=np.array(paths))
def slice_data(d,a,b=None):return tuple(x[a:b] for x in d)
def summary(r,j):return {k:float(v[j]) for k,v in r.items() if k!='path'}
def label(j):return '/'.join(str(round(x*100)) for x in W[j])
datasets={};runs={};out={'grid_count':len(W),'weights':W.tolist(),'base':int(BASE)}
for proxy in ['DVY','VIG']:
 ds,p,fx=old.get(proxy);closes=[old.linked(proxy,'SCHD'),old.linked('QQQ','QQQM'),old.bars('IEF'),old.linked('IAU','IAUM')];raw=np.array([[c[d][2] for c in closes] for d in ds]);data=(ds,p,raw,fx);datasets[proxy]=data
 cut=ds.index(dt.date(2016,10,31));actual=ds.index(dt.date(2021,7,1))
 for seg,d in [('full',data),('train',slice_data(data,0,cut+1)),('test',slice_data(data,cut)),('actual',slice_data(data,actual))]:
  for mode in ['whole','selective','hold']:
   r=sim(d,W,mode);runs[proxy,seg,mode]=r
   print(proxy,seg,mode,len(W),flush=True)
 # Match the previous scalar model independently.
 for mode in ['whole','selective']:
  check=old.simulate_compare(*data,mode);new=runs[proxy,'full',mode]
  for a,b in [('held','cagr'),('mdd','mdd'),('orders','orders')]:assert abs(check[a]-new[b][BASE])<1e-5,(proxy,mode,a,check[a],new[b][BASE])
out['regression']='PASS: prior scalar model matched for both modes and both proxies'
selections=[]
for cap in [15,18,20,25]:
 candidates=[]
 for mode in ['whole','selective']:
  eligible=np.ones(len(W),bool)
  for proxy in datasets:
   r=runs[proxy,'train',mode];eligible&=(r['mdd']>=-cap)&(r['usd_mdd']>=-30)
  score=np.minimum(*[runs[p,'train',mode]['cagr'] for p in datasets]);ids=np.flatnonzero(eligible)
  if len(ids):
   j=ids[np.argmax(score[ids])];candidates.append((score[j],mode,int(j),len(ids)))
 if candidates:
  best=max(candidates);selections.append(dict(cap=cap,mode=best[1],index=best[2],label=label(best[2]),train_score=best[0],eligible=sum(c[3] for c in candidates)))
out['selections']=selections
chosen=next(s for s in selections if s['cap']==20);j=chosen['index'];out['chosen']=chosen
named={'existing':int(BASE),'equal':int(np.flatnonzero(np.all(np.isclose(W,.25),axis=1))[0]),'candidate':j}
for weight in [[30,40,20,10],[20,30,30,20],[10,50,20,20],[15,35,30,20],[15,40,20,25],[15,45,20,20],[25,25,30,20]]:
 ids=np.flatnonzero(np.all(np.isclose(W,np.array(weight)/100),axis=1))
 if len(ids):named['/'.join(map(str,weight))]=int(ids[0])
for s in selections:named['risk'+str(s['cap'])]=s['index']
out['named']=named;out['results']={f'{p}_{seg}_{m}':[summary(r,i) for i in range(len(W))] for (p,seg,m),r in runs.items()}
# Explicit rolling start checks: these are overlapping retrospective windows.
out['rolling']=[]
for year in range(2006,2022):
 data=datasets['DVY'];ds=data[0];start=next(i for i,d in enumerate(ds) if d>=dt.date(year,10,30));end=max(i for i,d in enumerate(ds) if d<=dt.date(year+5,10,30))
 r=sim(slice_data(data,start,end+1),W[[BASE,j]],chosen['mode']);out['rolling'].append(dict(start=str(ds[start]),end=str(ds[end]),existing=summary(r,0),candidate=summary(r,1)))
out['sensitivity']=[]
for mode in ['whole','selective']:
 for freq in [1,3,12]:
  for band in [.03,.05,.075,.10]:
   r=sim(datasets['DVY'],W[[BASE,j]],mode,band=band,freq=freq);out['sensitivity'].append(dict(mode=mode,months=freq,band=band,existing=summary(r,0),candidate=summary(r,1)))
out['fees']=[]
for fee in [.0005,.001,.0025]:
 for mode in ['whole','selective']:
  r=sim(datasets['DVY'],W[[BASE,j]],mode,fee=fee);out['fees'].append(dict(fee=fee,mode=mode,existing=summary(r,0),candidate=summary(r,1)))
# Recompute C at the selected weights, preserving the original signal logic.
out['signal']=[]
for proxy,data in datasets.items():
 ds,p,raw,fx=data;signals=old.signals((ds,p,fx),proxy)|old.more_signals((ds,p,fx),proxy)
 factor=signals['squeeze']/np.array([.15,.4,.25,.2])
 for name,k in [('existing',BASE),('candidate',j)]:
  targets=W[k]*(.8+.2*factor)
  for seg,a in [('full',0),('test',ds.index(dt.date(2016,10,31))),('actual',ds.index(dt.date(2021,7,1)))]:
   res=old.simulate(ds[a:],p[a:],raw[a:],fx[a:],targets[a:],'squeeze',.22);out['signal'].append(dict(proxy=proxy,name=name,segment=seg,**res))
(ROOT/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('CHOSEN',chosen,'GRID',len(W),out['regression'],flush=True)
for name,k in named.items(): print(name,label(k),*[tuple(round(runs['DVY',seg,'selective'][metric][k],2) for metric in ['cagr','mdd']) for seg in ['full','train','test','actual']])
