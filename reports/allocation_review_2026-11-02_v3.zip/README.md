# 4-ETF allocation review v3 (2026-11-02)

Run: Python 3 + numpy, then `python review.py` from this extracted folder.
The review reads source files from selective_vs_whole_rebalance_2026-11-02/.
results.json contains every period/proxy/strategy result, the selected index,
all 24 trading-rule sensitivities, fees, rolling windows and C signal tests.
all_grid_results.csv contains 6,192 rows (258 weights x 2 proxies x 4 periods x 3 modes).

Data snapshot: 2006-10-30 through 2026-10-30. No fresh price download.
Yahoo adjusted closes and split-adjusted OHLC, with FRED DEXKOUS FX gap fill.
Original source SHA256 records are in sha256_manifest.json in the source folder.
DVY (alternative VIG) before SCHD; QQQ before QQQM; IAU before IAUM.
Initial KRW 100m, fractional holdings, reinvested distributions, no external flows.
One-way fee 0.1%; annual KRW 2.5m gain exemption and 22% tax assumed across history.
Approximate average cost basis reconstructed from adjusted/raw return differences.
Accrued capital-gains tax is deducted from NAV and paid next May; pro-rata asset sales
fund any cash shortfall. Personal dividend tax, FX conversion and transition tax excluded.
Holding CAGR excludes hypothetical final liquidation taxes. USD MDD is KRW net NAV
translated back to USD; it retains the Korean tax assumptions.

Grid: 5 percentage-point steps, SCHD/QQQM/IEF each 10-50%, gold 10-30%, equities <=70%.
Weights/strategy selected ONLY with 2006-10-30 through 2016-10-31 data, A or D,
quarterly review and 5pp band. Both proxies must have KRW MDD >=-20%, USD MDD >=-30%.
Maximize the minimum CAGR across the two proxies. These constraints are research choices.
Selected: 10/45/25/20, A whole rebalance. User supplied balanced ~20% loss tolerance.
2016-10-31 through 2026-10-30 is a frozen-allocation evaluation with fresh KRW 100m.
The split was designed retrospectively after earlier research used the full history.
It is NOT an independently untouched or prospective out-of-sample result.
Actual ETF period: 2021-07-01 through 2026-10-30. Overlaps the evaluation period.
16 rolling 5-year windows overlap and cannot be treated as independent trials.
24 rule sensitivities are descriptive full-history comparisons, not selected held-out rules.
C was recalculated only at existing/selected weights, not optimized over all 258 weights.
C uses original signal code: 90% core + 10% weekly Squeeze tactical sleeve.
A/D/B use new vectorized sim; four full-history scalar regression comparisons passed.
No historical maximum drawdown is a future loss ceiling. Stress examples are assumptions.

PPT v3 has 30 slides: 1-14 new allocation review, 15-29 existing-weight evidence,
30 conclusion. Previous v2 remains unchanged. No Pine or live-account change.
Validation: original-model numeric regressions, weight sums, selected constraints,
PPT package relationships, layout geometry, and Microsoft PowerPoint rendering.
