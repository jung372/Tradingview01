import json, pathlib, tempfile, datetime as dt, bisect, math
base=pathlib.Path(__file__).resolve().parent
def series(t):
    obj=json.loads((base/(t+'.json')).read_bytes())['chart']['result'][0]
    out={}
    for ts,v in zip(obj['timestamp'],obj['indicators']['adjclose'][0]['adjclose']):
        if v is None: continue
        timestamp=dt.datetime.fromtimestamp(ts,dt.timezone.utc)
        if t=='KRW=X': timestamp+=dt.timedelta(hours=12) # London midnight date during BST
        out[timestamp.date()]=v
    return out
fx=series('KRW=X')
fxdates=sorted(fx)
def rate(d):
    k=fxdates[bisect.bisect_right(fxdates,d)-1]
    assert 0 <= (d-k).days <= 5
    return fx[k]
def stats(days,path):
    peak=path[0]; peakdate=days[0]; m=0; a=b=days[0]
    for d,v in zip(days,path):
        if v>peak: peak=v; peakdate=d
        if v/peak-1<m: m=v/peak-1; a,b=peakdate,d
    ret=path[-1]/path[0]
    return [round(x*100,2) for x in (ret-1,ret**(365.2425/(days[-1]-days[0]).days)-1,m)]+[str(a),str(b)]
weights=[[.25,.25,.30,.20,0,0],[.25,.15,.40,.20,0,0],[.25,.15,.30,.20,.05,.05]]
def run(names,days,prices,w,cost=.001):
    vals=[x/(1+cost*(1-w[-1])) for x in w]
    path=[1.]; orders=0; events=0
    for prev,d in zip(days,days[1:]):
        total=sum(vals)
        trigger=(d.year,(d.month-1)//3)!=(prev.year,(prev.month-1)//3) and max(abs(x/total-y) for x,y in zip(vals,w))>=.05-1e-12
        vals=[v*(p[d]/p[prev]) for v,p in zip(vals[:-1],prices)]+[vals[-1]]
        total=sum(vals)
        if trigger:
            after=total
            for _ in range(8):
                after=total-cost*sum(abs(after*y-x) for x,y in zip(vals[:-1],w[:-1]))
            orders+=sum(abs(after*y-x)>1e-10 for x,y in zip(vals[:-1],w[:-1]))
            vals=[after*y for y in w];events+=1
        path.append(sum(vals))
    kr=[v*rate(d)/rate(days[0]) for v,d in zip(path,days)]
    ix=[i for i,d in enumerate(days) if d.year==2022]; lo=max(0,ix[0]-1) if ix else 0; hi=ix[-1]+1 if ix else len(days); lo,hi=(lo,hi) if hi-lo>1 else (0,len(days))
    return stats(days,path),stats(days,kr),stats(days[lo:hi],path[lo:hi]),stats(days[lo:hi],kr[lo:hi]),(events,orders)
for tickers in [('SCHD','QQQM','IEF','IAUM','SGOV'),('SCHD','QQQ','IEF','IAU','BIL')]:
    prices=list(map(series,tickers)); dates=sorted(set.intersection(*(set(p) for p in prices)))
    print(tickers,dates[0],dates[-1],len(dates))
    print('2022 asset returns',[(t,round(100*(p[dt.date(2022,12,30)]/p[dt.date(2021,12,31)]-1),2)) for t,p in zip(tickers,prices)])
    for w in weights:
        print(run(tickers,dates,prices,w))
        print('cost0/20bp kr mdd',*[run(tickers,dates,prices,w,c)[1][2] for c in (0,.002)])

# Restart the same pre-specified portfolios each January, evaluate a full 3 years.
    starts=[y for y in range(dates[0].year+1,dates[-1].year-2)]
    windows=[]
    for y in starts:
        start=max(d for d in dates if d.year==y-1)
        subset=[d for d in dates if d>=start and d.year<=y+2]
        windows.append([run(tickers,subset,prices,w)[1][2] for w in weights])
    print('3-year KRW drawdown windows',starts,windows)
    if dates[0].year < 2020:
        ds=[d for d in dates if dt.date(2019,12,31)<=d<=dt.date(2020,12,31)]
        print('2020 reset USD CAGR/MDD; KRW',[(run(tickers,ds,prices,w)[0][:3],run(tickers,ds,prices,w)[1][:3]) for w in weights])


