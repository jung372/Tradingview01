"""Personal capital gains tax scenario, not a brokerage ledger. Python + NumPy."""
from methods import get,signals,more_signals,run,linked,bars,root,np,dt
import json
from collections import defaultdict
INITIAL=1e8; FEE=.001; EXEMPT=2_500_000
def tax(g,rate):return max(0.,g-EXEMPT)*rate
def simulate(ds,price,raw,fx,targets,key,rate,harvest=0,gap=0):
    shares_value=INITIAL/fx[0]*targets[0]/(1+FEE*targets[0].sum())
    basis=shares_value*fx[0]*(1+FEE);cash=(INITIAL-basis.sum())/fx[0]
    gains=defaultdict(float);paid={};peak=INITIAL;mdd=0.; trades=0;yearrows={};harvest_events=0;harvest_gain=0.;harvest_cost=0.
    for i in range(1,len(ds)):
        d,prev=ds[i],ds[i-1];t=targets[i];v=shares_value
        quarter=(d.month-1)//3!=(prev.month-1)//3
        reb=np.any(t!=targets[i-1]) or (quarter and np.max(abs(v/(cash+v.sum())-t))>=.05-1e-12)
        if key=='hold':reb=False
        if key=='quarter':reb=quarter
        totalret=price[i]/price[i-1];priceret=raw[i]/raw[i-1]
        # The reinvestment implied by adjusted vs split-adjusted price returns has its own KRW basis.
        extra=totalret-priceret
        basis+=v*np.where(extra>1e-5,extra,0)*fx[i]
        v=v*totalret
        remit=0.
        if d.month==5 and prev.month!=5:
            remit=tax(gains[d.year-1],rate);paid[d.year-1]=remit
        total=cash+v.sum()-remit/fx[i]
        if reb or (remit and cash<remit/fx[i]):
            target=t if reb else v/v.sum() # liquidate pro rata to fund the tax cash shortfall
            net=total
            for _ in range(7):net=total-FEE*abs(target*net-v).sum()
            new=net*target; delta=new-v
            sell=np.maximum(-delta,0);buy=np.maximum(delta,0)
            b_sold=basis*np.divide(sell,v,out=np.zeros_like(v),where=v>0)
            gains[d.year]+=(sell*fx[i]*(1-FEE)-b_sold).sum()
            basis+=buy*fx[i]*(1+FEE)-b_sold
            shares_value=new;cash=net-new.sum()
            trades+=int(np.sum(abs(delta)>1e-6))
        else:
            shares_value=v;cash-=remit/fx[i]
        before_gain=gains[d.year]
        if harvest and d.month==12 and prev < dt.date(d.year,12,15) <= d:
            # Use realized KRW gains and remaining annual headroom known on the trade date.
            room=max(0.,harvest-gains[d.year])
            efficiency=np.where(shares_value>0,1-FEE-basis/np.maximum(shares_value*fx[i],1e-30),-1)
            for k in np.argsort(efficiency)[::-1]:
                if efficiency[k]<=0 or room<=1:continue
                sold=min(shares_value[k],room/(fx[i]*efficiency[k]))
                gain=sold*fx[i]*efficiency[k]
                cash_back=sold*(1-FEE)
                bought=cash_back/(1+FEE+gap)
                # Trade only when the potential eventual 22% saving exceeds the round-trip execution cost.
                cost=(sold-bought)*fx[i]
                if gain*rate<=cost:continue
                removed=basis[k]*sold/shares_value[k]
                basis[k]+=bought*(1+FEE+gap)*fx[i]-removed
                shares_value[k]+=bought-sold
                gains[d.year]+=gain;room-=gain;trades+=2
                harvest_events+=1;harvest_gain+=gain;harvest_cost+=cost
            assert gains[d.year]<=max(harvest,before_gain)+1e-6

        nav=(shares_value.sum()+cash)*fx[i]
        liability=tax(gains[d.year],rate)+(0 if d.year-1 in paid else tax(gains[d.year-1],rate))
        netnav=nav-liability
        peak=max(peak,netnav);mdd=min(mdd,netnav/peak-1)
    held=netnav
    proceeds=shares_value.sum()*fx[-1]*(1-FEE)
    liquidation_gain=proceeds-basis.sum()
    liq_tax=tax(gains[d.year]+liquidation_gain,rate)
    liq=cash*fx[-1]+proceeds-liq_tax-(0 if d.year-1 in paid else tax(gains[d.year-1],rate))
    years=(ds[-1]-ds[0]).days/365.2425
    apr=lambda x:round(((x/INITIAL)**(1/years)-1)*100,3)
    return dict(harvest_events=harvest_events,harvest_gain=round(harvest_gain),harvest_cost=round(harvest_cost),end_net=round(liq),held=apr(held),liquidated=apr(liq),mdd=round(mdd*100,3),trades=trades,
                realized_tax=round(sum(paid.values())+liability),final_tax_if_sold=round(liq_tax),years_taxable=int(sum(tax(g,rate)>0 for g in gains.values())),
                annual={str(y):[round(g),round(tax(g,rate))] for y,g in sorted(gains.items())})

results=[]
for proxy in ('DVY','VIG'):
    data=get(proxy);ds,p,fx=data;tar=signals(data,proxy)|more_signals(data,proxy)
    close=[linked(proxy,'SCHD'),linked('QQQ','QQQM'),bars('IEF'),linked('IAU','IAUM')]
    raw=np.array([[c[d][2] for c in close] for d in ds])
    for key in ('base','hold','roc'):
        for amount,gap in ((0,0),(2_300_000,0),(2_500_000,0),(2_300_000,.0005)):
            v=simulate(ds,p,raw,fx,tar[key],key,.22,amount,gap)
            results.append(dict(proxy=proxy,strategy=key,harvest_target=amount,reentry_gap=gap,**v))
            print(proxy,key,amount,gap,*[v[k] for k in ('held','liquidated','end_net','mdd','harvest_events','harvest_gain','harvest_cost')])
(root/'harvest_results.json').write_text(json.dumps(results,indent=1))

