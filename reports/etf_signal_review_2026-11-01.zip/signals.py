"""Run next to model.py and the input data files with Python and numpy."""
from model import get, sim, root, np, dt, json
from collections import defaultdict,Counter

weight=np.array([.15,.40,.25,.20])
def signal(ticker):
    row=json.loads((root/(ticker+'.json')).read_bytes())['chart']['result'][0]
    q=row['indicators']['quote'][0]
    bars=defaultdict(list)
    for t,h,l,c in zip(row['timestamp'],q['high'],q['low'],q['close']):
        d=dt.datetime.fromtimestamp(t,dt.timezone.utc).date()
        assert h and l and c
        bars[d-dt.timedelta(days=d.weekday())].append((h,l,c))
    result={}; closes=[]; tr=[]; vf=[]; atr=None; upper=lower=prev=None; up=False; previous=None
    for week,days in sorted(bars.items()):
        # Current week can only see the state from the prior completed week.
        result[week]=previous
        h=max(v[0] for v in days); l=min(v[1] for v in days); c=days[-1][2]
        tr.append(max(h-l,abs(h-prev),abs(l-prev)) if prev is not None else h-l)
        if len(tr)>=10:
            atr=np.mean(tr[-10:]) if atr is None else (9*atr+tr[-1])/10
            u=(h+l)/2+3*atr; lo=(h+l)/2-3*atr
            first=upper is None
            upper=u if first or u<upper or prev>upper else upper
            lower=lo if first or lo>lower or prev<lower else lower
            up=False if first else (c>=lower if up else c>upper)
        closes.append(c)
        if len(closes)>=22:
            high=max(closes[-22:]); vf.append(100*(high-l)/high)
        if len(vf)>=50:
            fear=vf[-1]>=np.mean(vf[-20:])+2*np.std(vf[-20:]) or vf[-1]>=.85*max(vf[-50:])
            previous=(up,fear)
        prev=c
    return result
signals={t:signal(t) for t in ('DVY','VIG','SCHD','QQQ','QQQM','IEF','IAU','IAUM')}
def run(dataset,proxy,mode,wait):
    ds,p,f=dataset; h=weight.copy()/1.001; cash=0.; path=[1.]; deferred=np.zeros(4); due=None
    cnt=Counter()
    for i in range(1,len(ds)):
        d=ds[i]; prev=ds[i-1]
        trig=(d.month-1)//3!=(prev.month-1)//3 and max(abs(h/(h.sum()+cash)-weight))>=.05-1e-12
        h*=p[i]/p[i-1]
        if i==due:
            cash-=deferred.sum()*1.001;h+=deferred
            cnt['orders']+=sum(deferred>1e-12);due=None
        if trig:
            assert due is None
            gross=h.sum()+cash; net=gross;cnt['events']+=1
            for _ in range(8):net=gross-.001*abs(net*weight-h).sum()
            delta=net*weight-h; deferred=np.zeros(4)
            week=d-dt.timedelta(days=d.weekday())
            for k,(original,actual) in enumerate([(proxy,'SCHD'),('QQQ','QQQM'),('IEF','IEF'),('IAU','IAUM')]):
                sg=signals[actual].get(week) or signals[original].get(week)
                if mode and delta[k]>0 and sg and not sg[0]:
                    fraction=.5 if sg[1] or mode=='ST' else 1.
                    deferred[k]=delta[k]*fraction
                    cnt['fear' if sg[1] else 'normal']+=1
            now=delta-deferred;cash-=now.sum()+.001*abs(now).sum(); h+=now
            cnt['orders']+=sum(abs(now)>1e-12)
            if deferred.any():due=i+wait
        assert cash>=-1e-10
        path.append(h.sum()+cash)
    U=np.array(path);K=U*f/f[0]
    years=(ds[-1]-ds[0]).days/365.2425
    stats=lambda x: [round(100*(x[-1]**(1/years)-1),4),round(100*(x/np.maximum.accumulate(x)-1).min(),4)]
    return U,stats(U)+stats(K),dict(cnt)
for proxy in ('DVY','VIG'):
    data=get(proxy)
    for tag,start in [('full',0),('exact',data[0].index(dt.date(2021,7,1)))]:
        sub=tuple(x[start:] for x in data)
        expected=sim(sub,ww=weight[None,:])[6][:,0]
        for mode,wait in [(None,5),('ST',5),('ST+VF',5),('ST+VF',1),('ST+VF',10)]:
            path,stats,counts=run(sub,proxy,mode,wait)
            if mode is None:assert np.allclose(path,expected,rtol=1e-11)
            print(proxy,tag,mode,wait,stats,counts)

