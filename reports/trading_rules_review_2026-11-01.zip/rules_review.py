from model import root, np, json, dt, get, sim
from collections import defaultdict
W=np.array([.15,.40,.25,.20])
def bars(t):
    r=json.loads((root/(t+'.json')).read_bytes())['chart']['result'][0]
    q=r['indicators']['quote'][0]
    return {dt.datetime.fromtimestamp(ts,dt.timezone.utc).date(): np.array(h) for ts,*h in zip(r['timestamp'],q['high'],q['low'],q['close'])}
def linked(a,b):
    x,y=bars(a),bars(b); day=min(y); scale=y[day][2]/x[day][2]
    return {**{d:h*scale for d,h in x.items() if d<day},**y}
def signals(data,proxy):
    ds,p,_=data; n=len(ds); stocks=[linked(proxy,'SCHD'),linked('QQQ','QQQM'),bars('IEF'),linked('IAU','IAUM')]
    target={k:np.tile(W,(n,1)) for k in ['base','st','ce','ma','roc']}
    for k,asset in enumerate(stocks):
        weeks=defaultdict(list); last=None; tr=[]; c=[]; atr={}; ub=lb=ls=ss=None; st=False; ce=True
        for i,d in enumerate(ds):weeks[d-dt.timedelta(days=d.weekday())].append(i)
        for ids in weeks.values():
            if ub is not None:target['st'][ids,k]*=1 if st else .5
            if ls is not None:target['ce'][ids,k]*=1 if ce else .5
            a=np.array([asset[ds[i]] for i in ids]); h=max(a[:,0]); l=min(a[:,1]); close=a[-1,2]
            tr.append(max(h-l,abs(h-last),abs(l-last)) if last is not None else h-l); c.append(close)
            for period in [10,22]:
                if len(c)<period:continue
                atr[period]=(np.mean(tr[-period:]) if period not in atr else (atr[period]*(period-1)+tr[-1])/period)
                if period==10:
                    u=(h+l)/2+3*atr[10]; v=(h+l)/2-3*atr[10]; first=ub is None
                    ub=u if first or last>ub else min(u,ub); lb=v if first or last<lb else max(v,lb)
                    st=False if first else (close>=lb if st else close>ub)
                else:
                    lo=max(c[-22:])-3*atr[22]; hi=min(c[-22:])+3*atr[22]
                    oldlo=lo if ls is None else ls; oldhi=hi if ss is None else ss
                    ce=True if close>oldhi else False if close<oldlo else ce
                    ls=max(oldlo,lo) if last>oldlo else lo;ss=min(oldhi,hi) if last<oldhi else hi
            last=close
    months=defaultdict(list)
    for i,d in enumerate(ds):months[(d.year,d.month)].append(i)
    ends=[]
    for ids in months.values():
        if len(ends)>=10:
            hist=p[ends[-10:]]; target['ma'][ids]=W*np.where(hist[-1]>=hist.mean(0),1,.5)
        if len(ends)>=13:
            ret=p[ends[-1]]/p[ends[-13]]-1; strongest=np.argmax(ret);weakest=np.argmin(ret)
            target['roc'][ids,strongest]+=.10;target['roc'][ids,weakest]-=.10
        ends.append(ids[-1])
    return target
def more_signals(data,proxy):
    ds,p,_=data;n=len(ds); names=['hold','quarter','donchian','rsi','squeeze','macd']
    mats={k:np.tile(W,(n,1)) for k in names}
    weeks=defaultdict(list)
    for i,d in enumerate(ds): weeks[d-dt.timedelta(days=d.weekday())].append(i)
    rsi_scores=np.full((n,4),50.)
    for k,asset in enumerate([linked(proxy,'SCHD'),linked('QQQ','QQQM'),bars('IEF'),linked('IAU','IAUM')]):
        highs=[];lows=[];cl=[];trs=[];dev=[];g=[];loss=[];gain=avg_loss=None; rsi=50.
        channel=True;squeeze_long=True;inside=False;e12=e26=sig=None;mac=True
        for ids in weeks.values():
            for key,flag in [('donchian',channel),('squeeze',squeeze_long),('macd',mac)]:
                if not flag:mats[key][ids,k]*=.5
            rsi_scores[ids,k]=rsi
            a=np.array([asset[ds[i]] for i in ids]);h,l,c=max(a[:,0]),min(a[:,1]),a[-1,2]
            if len(cl)>=20:
                if c>max(highs[-20:]):channel=True
                elif c<min(lows[-10:]):channel=False
            if cl:
                change=c-cl[-1];g.append(max(0,change));loss.append(max(0,-change))
                if len(g)>=14:
                    gain=np.mean(g[-14:]) if gain is None else (13*gain+g[-1])/14
                    avg_loss=np.mean(loss[-14:]) if avg_loss is None else (13*avg_loss+loss[-1])/14
                    rsi=100*gain/(gain+avg_loss) if gain+avg_loss else 50.
            trs.append(max(h-l,abs(h-cl[-1]),abs(l-cl[-1])) if cl else h-l)
            highs.append(h);lows.append(l);cl.append(c)
            e12=c if e12 is None else e12+(2/13)*(c-e12)
            e26=c if e26 is None else e26+(2/27)*(c-e26)
            diff=e12-e26;sig=diff if sig is None else sig+.2*(diff-sig)
            if len(cl)>=35:mac=diff>=sig
            if len(cl)>=20:
                avg=np.mean(cl[-20:]);dev.append(c-(.5*avg+.25*(max(highs[-20:])+min(lows[-20:]))))
                now=2*np.std(cl[-20:])<1.5*np.mean(trs[-20:])
                if inside and not now and len(dev)>=20:
                    slope,intercept=np.polyfit(np.arange(20),dev[-20:],1);squeeze_long=intercept+19*slope>=0
                inside=now
    # Monthly contrarian tilt: when minimum weekly RSI <30 tilt 5pp from highest to lowest for the month.
    months=defaultdict(list)
    for i,d in enumerate(ds):months[(d.year,d.month)].append(i)
    for ids in months.values():
        r=rsi_scores[ids[0]]
        if min(r)<30:
            mats['rsi'][ids,r.argmin()]+=.05;mats['rsi'][ids,r.argmax()]-=.05
    return mats

def run(data,targets,start,end,cost,key,cash_apr=0):
    ds,p,f=data; dates=ds[start:end+1]; mat=targets[start:end+1]; h=mat[0]/(1+cost*mat[0].sum()); cash=1-h.sum()*(1+cost); path=[1.]; counts=0; events=0
    for j in range(1,len(dates)):
        i=start+j; t=mat[j]
        flag=np.any(t!=mat[j-1]) or ((dates[j-1].month-1)//3!=(dates[j].month-1)//3 and max(abs(h/(cash+h.sum())-t))>=.05-1e-12)
        if key=='hold':flag=False
        if key=='quarter':flag=(dates[j-1].month-1)//3!=(dates[j].month-1)//3
        cash*=(1+cash_apr)**((dates[j]-dates[j-1]).days/365.2425)
        h*=p[i]/p[i-1]
        if flag:
            total=h.sum()+cash;net=total
            for _ in range(7):net=total-cost*abs(net*t-h).sum()
            counts+=sum(abs(net*t-h)>1e-10);events+=1;h=net*t;cash=net*(1-t.sum())
        assert cash>=-1e-9
        path.append(cash+h.sum())
    u=np.array(path);k=u*f[start:end+1]/f[start];years=(dates[-1]-dates[0]).days/365.2425
    def stats(x):return [(x[-1]**(1/years)-1)*100,(x/np.maximum.accumulate(x)-1).min()*100]
    return [*stats(k),*stats(u),int(counts),events],u
for proxy in ['DVY','VIG']:
    data=get(proxy);ds=data[0]; tar=signals(data,proxy) | more_signals(data,proxy); ref=sim(data,ww=W[None,:])[6][:,0]
    for group,a,b in [('full',0,len(ds)-1),('first',0,ds.index(dt.date(2016,10,31))),('later',ds.index(dt.date(2016,10,31)),len(ds)-1),('exact',ds.index(dt.date(2021,7,1)),len(ds)-1)]:
        for key,mat in tar.items():
            res,path=run(data,mat,a,b,.001,key)
            if group=='full' and key=='base':assert np.allclose(ref,path,rtol=1e-11)
            print(proxy,group,key,' '.join(f'{x:.3f}' for x in res))


    for key,mat in tar.items():
        res,_=run(data,mat,0,len(ds)-1,.002,key,.03)
        print(proxy,'higher_cost_cash_3pct',key,' '.join(f'{x:.3f}' for x in res))
