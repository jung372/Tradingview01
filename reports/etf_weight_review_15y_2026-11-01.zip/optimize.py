"""Run beside etf_backtest_2026-11-01.zip. Requires Python 3 and numpy."""
import json, zipfile, pathlib, datetime as dt, bisect
import numpy as np
root=pathlib.Path(__file__).parent
z=zipfile.ZipFile(root/'etf_backtest_2026-11-01.zip')
def prices(t):
    r=json.loads(z.read(t+'.json'))['chart']['result'][0]
    return {(dt.datetime.fromtimestamp(ts,dt.timezone.utc)+dt.timedelta(hours=12 if t=='KRW=X' else 0)).date():v for ts,v in zip(r['timestamp'],r['indicators']['adjclose'][0]['adjclose']) if v and v>0}
w=np.array([(a,b,c,20-a-b-c) for a in range(21) for b in range(21-a) for c in range(21-a-b)],float)/20
def idx(v):return np.flatnonzero(np.all(np.isclose(w,v),axis=1))[0]
base=idx([.25,.25,.30,.20])
div=(w.min(1)>=.10)&(w.max(1)<=.40)&(w[:,3]<=.25)&(w[:,:2].sum(1)<=.700000001)
def data(names):
    p=[prices(t) for t in names]; fx=prices('KRW=X'); keys=sorted(fx)
    d=sorted(t for t in set.intersection(*(set(a) for a in p)) if dt.date(2011,10,30)<=t<=dt.date(2026,10,30))
    f=[]
    for t in d:
        k=keys[bisect.bisect_right(keys,t)-1]; assert (t-k).days<=5
        f.append(fx[k])
    return d,np.array([[a[t] for a in p] for t in d]),np.array(f)
def sim(data,start=0,stop=None,ww=w,cost=.001):
    ds,p,f=[x[start:stop] for x in data]
    val=ww.copy()/(1+cost); U=np.empty((len(ds),len(ww))); U[0]=1
    events=np.zeros(len(ww),int); orders=events.copy()
    for i in range(1,len(ds)):
        quarterly=(ds[i-1].month-1)//3!=(ds[i].month-1)//3
        if quarterly: tr=np.max(abs(val/val.sum(1)[:,None]-ww),axis=1)>=.05-1e-12
        val*=p[i]/p[i-1]
        if quarterly and tr.any():
            pre=val[tr]; wt=ww[tr]; gross=pre.sum(1)[:,None]; net=gross
            for _ in range(6):net=gross-cost*abs(net*wt-pre).sum(1)[:,None]
            val[tr]=net*wt;events[tr]+=1;orders[tr]+=(abs(net*wt-pre)>1e-10).sum(1)
        U[i]=val.sum(1)
    K=U*(f/f[0])[:,None]
    def calc(P):
        return (P[-1]**(365.2425/(ds[-1]-ds[0]).days)-1)*100,(P/np.maximum.accumulate(P,axis=0)-1).min(0)*100
    return (*calc(U),*calc(K),events,orders,U,K,ds)
def pick(s,kr=3,us=5,eq=.70):
    eligible=div&(w[:,:2].sum(1)<=eq+1e-9)&(s[3]>=s[3][base]-kr)&(s[1]>=s[1][base]-us)
    return np.flatnonzero(eligible)[s[2][eligible].argmax()]
def label(j):return '/'.join(map(str,np.rint(w[j]*100).astype(int)))
def describe(s,j):
    path=s[7][:,j]; ds=s[8]; b=(path/np.maximum.accumulate(path)).argmin(); a=path[:b+1].argmax(); hit=np.flatnonzero(path[b:]>=path[a])
    return label(j),*(round(float(t[j]),2) for t in s[:4]),int(s[4][j]),int(s[5][j]),str(ds[a]),str(ds[b]),str(ds[b+hit[0]]) if len(hit) else 'unrecovered'
proxy=data(['SCHD','QQQ','IEF','IAU']); exact=data(['SCHD','QQQM','IEF','IAUM']); s=sim(proxy); j=pick(s)
print('Grid',len(w),'diversification',div.sum(), 'dates',proxy[0][0],proxy[0][-1])
print('USD CAGR/MDD, KRW CAGR/MDD, rebalance events / trades excl initial, KRW peak/trough/recovered')
for k in dict.fromkeys([base,j,s[2].argmax(),*[pick(s,eq=x) for x in (.55,.60,.65)],pick(s,0,0),pick(s,6,10)]):print(describe(s,k))
print('strict,default,loose',*[label(pick(s,k,u)) for k,u in [(0,0),(3,5),(6,10)]])
sel=[base,j]; ww=w[sel]; e=sim(exact,ww=ww)
for i in range(2):print('Exact',label(sel[i]),[round(float(x[i]),2) for x in e[:6]])
for yr in [2020,2022]:
    ds=proxy[0]; ix=[i for i,t in enumerate(ds) if t.year==yr]; uv=s[6][ix[0]-1:ix[-1]+1,sel]; kv=s[7][ix[0]-1:ix[-1]+1,sel]
    for path in [uv,kv]:print(yr,'return,dd',np.round((path[-1]/path[0]-1)*100,2),np.round((path/np.maximum.accumulate(path,axis=0)-1).min(0)*100,2))
# Five trailing years, selection frozen for each following year. Boundaries use last October session.
ds=proxy[0]; ends={y:max(i for i,t in enumerate(ds) if t.year==y and t.month==10) for y in range(2011,2027)}
r=[]
for year in range(2016,2026):
    train=sim(proxy,ends[year-5],ends[year]+1)
    win=pick(train); test=sim(proxy,ends[year],ends[year+1]+1,ww=w[[base,win]])
    yearly=test[7][-1];r.append(yearly)
    print('forward',year,label(win),np.round((yearly-1)*100,2))
print('forward geom (annual reset with fresh buy costs)',(np.prod(r,axis=0)**.1-1)*100)

print('Candidate sensitivity at 0 and 20bp per leg, USD/KRW CAGR/MDD')
for fee in (0,.002):
    fee_result=sim(proxy,ww=w[[base,j]],cost=fee)
    print(fee,[[round(float(v[i]),3) for v in fee_result[:4]] for i in range(2)])
print('Exact series dates', exact[0][0],exact[0][-1],len(exact[0]))
print('Selected baseline-relative MDD loss increase KRW and USD:',s[3][base]-s[3][j],s[1][base]-s[1][j])
assert np.allclose(w.sum(1),1) and len(w)==1771 and len(r)==10
assert np.allclose(s[6][0],1) and np.all(s[6]>0) and np.allclose(s[7][-1]/s[6][-1],proxy[2][-1]/proxy[2][0])
