"""Selective vs whole-portfolio quarterly rebalance. Existing NumPy research model.
Run next to model.py, methods.py, tax_core.py and source JSON/FX files.
"""
from tax_core import *
import math
W=np.array([.15,.40,.25,.20])
NAMES=['SCHD','QQQM','IEF','IAUM']

def partial_order(v,cash,mask,fee):
    """Target selected assets only; sell first, proportionally cap buys by cash.
    Solve target weights against post-fee NAV. No leverage or external flows.
    """
    gross=v.sum()+cash;net=gross
    for _ in range(60):
        desired=np.where(mask,W*net,v)
        sells=np.maximum(v-desired,0);buys=np.maximum(desired-v,0)
        available=cash+sells.sum()*(1-fee)
        scale=min(1.,max(0.,available)/(buys.sum()*(1+fee))) if buys.sum()>0 else 1.
        buys*=scale
        after=gross-fee*(sells.sum()+buys.sum())
        if abs(net-after)<1e-10:break
        net=after
    new=v-sells+buys
    newcash=cash+sells.sum()*(1-fee)-buys.sum()*(1+fee)
    assert newcash>=-1e-7
    assert np.allclose(new[~mask],v[~mask],rtol=0,atol=1e-10)
    assert abs(new.sum()+newcash-(gross-fee*abs(new-v).sum()))<1e-7
    return new,max(0.,newcash),scale

def simulate_compare(ds,price,raw,fx,key,fee=.001,rate=.22):
    v=INITIAL/fx[0]*W/(1+fee);basis=v*fx[0]*(1+fee);cash=0.
    gains=defaultdict(float);paid={};peak=INITIAL;mdd=0.;liability=0.
    rows=[];trace=[INITIAL];cash_weights=[0.];orders=taxorders=events=shortfalls=0;fees=0.
    for i in range(1,len(ds)):
        d,prev=ds[i],ds[i-1]
        quarter=(d.month-1)//3!=(prev.month-1)//3
        prev_weights=v/(cash+v.sum())
        mask=abs(prev_weights-W)>=.05-1e-12
        reb=quarter and mask.any()
        totalret=price[i]/price[i-1];priceret=raw[i]/raw[i-1]
        extra=totalret-priceret
        basis+=v*np.where(extra>1e-5,extra,0)*fx[i]
        v=v*totalret
        remit=0.
        if d.month==5 and prev.month!=5:
            remit=tax(gains[d.year-1],rate);paid[d.year-1]=remit
        old=v.copy(); reason=None;scale=1.
        cash-=remit/fx[i]
        # May cannot also be the first trading day of a new calendar quarter.
        if cash < -1e-8:
            needed=-cash/(1-fee);v=old*(1-needed/old.sum())
            cash+=needed*(1-fee);reason='tax'
        elif reb:
            if key=='whole':
                total=cash+v.sum();net=total
                for _ in range(7):net=total-fee*abs(W*net-v).sum()
                v=net*W;cash=net-v.sum()
            elif key=='selective':v,cash,scale=partial_order(v,cash,mask,fee)
            else:raise ValueError(key)
            reason='rebalance'
            shortfalls+=int(scale<1-1e-9)
        if reason:
            delta=v-old;sell=np.maximum(-delta,0);buy=np.maximum(delta,0)
            soldbasis=basis*np.divide(sell,old,out=np.zeros_like(old),where=old>0)
            gains[d.year]+=(sell*fx[i]*(1-fee)-soldbasis).sum()
            basis+=buy*fx[i]*(1+fee)-soldbasis
            n=int((abs(delta)>1e-6).sum());orders+=n
            taxorders+=n if reason=='tax' else 0
            events+=int(reason=='rebalance' and n>0)
            fees+=fee*abs(delta).sum()*fx[i]
            rows.append(dict(date=str(d),reason=reason,flagged=[NAMES[j] for j in np.flatnonzero(mask)],
                prev_weights=prev_weights.tolist(),delta_usd=delta.tolist(),cash_usd=float(cash),buy_fill=float(scale)))
        assert cash>=-1e-6 and v.min()>=0 and basis.min()>-1e-5
        nav=(v.sum()+cash)*fx[i]
        liability=tax(gains[d.year],rate)+(0 if d.year-1 in paid else tax(gains[d.year-1],rate))
        netnav=nav-liability;trace.append(netnav);cash_weights.append(cash/(cash+v.sum()))
        peak=max(peak,netnav);mdd=min(mdd,netnav/peak-1)
    proceeds=v.sum()*fx[-1]*(1-fee)
    liqtax=tax(gains[d.year]+proceeds-basis.sum(),rate)
    liq=cash*fx[-1]+proceeds-liqtax-(0 if d.year-1 in paid else tax(gains[d.year-1],rate))
    years=(ds[-1]-ds[0]).days/365.2425
    apr=lambda x:((x/INITIAL)**(1/years)-1)*100
    annual={}
    for year in [2008,2020,2022]:
        before=[j for j,t in enumerate(ds) if t.year<year];within=[j for j,t in enumerate(ds) if t.year==year]
        if before and within:annual[str(year)]=(trace[within[-1]]/trace[before[-1]]-1)*100
    return dict(held=apr(netnav),liquidated=apr(liq),mdd=mdd*100,end_liquidated=liq,
        orders=orders,tax_orders=taxorders,rebalance_events=events,shortfall_events=shortfalls,
        average_cash=np.mean(cash_weights)*100,max_cash=max(cash_weights)*100,end_cash=cash_weights[-1]*100,
        realized_tax=sum(paid.values())+liability,final_tax=liqtax,fees_ex_initial_final=fees,
        end_weights=(v/(v.sum()+cash)*100).tolist(),annual=annual,trace=trace,ledger=rows)

def checks():
    # Sell one winner; untouched assets truly stay untouched.
    v=np.array([15.,46.,24.,15.]);mask=np.array([False,True,False,False])
    nv,c,scale=partial_order(v,0,mask,.001)
    assert abs(nv[1]/(nv.sum()+c)-.4)<1e-10 and c>0
    # Cash-constrained buy with no funding: no trade, no hidden deposit.
    v=np.array([15.,34.,25.,26.]);mask=np.array([False,True,False,False])
    nv,c,scale=partial_order(v,0,mask,.001)
    assert np.array_equal(nv,v) and c==0 and scale==0
    # Multiple simultaneous buy requests receive the same fill fraction.
    v=np.array([10.,30.,25.,20.]);mask=np.array([True,True,False,False])
    nv,c,scale=partial_order(v,5,mask,.001)
    assert 0<scale<1 and c<1e-9 and np.allclose(nv[~mask],v[~mask])
    # Cost-free selected target can be checked by hand.
    nv,c,scale=partial_order(np.array([15.,46.,24.,15.]),0,np.array([0,1,0,0],bool),0)
    assert np.array_equal(nv,[15,40,24,15]) and c==6
    print('Four selective-order invariant scenarios PASS')

def main():
    checks();results=[];paths={};ledgers={};regressions=0
    for proxy in ('DVY','VIG'):
        data=get(proxy);ds,p,fx=data
        closes=[linked(proxy,'SCHD'),linked('QQQ','QQQM'),bars('IEF'),linked('IAU','IAUM')]
        raw=np.array([[c[d][2] for c in closes] for d in ds])
        for segment,start in [('full',0),('later',ds.index(dt.date(2016,10,31))),('actual',ds.index(dt.date(2021,7,1)))]:
            for fee in ([.0005,.001,.0025] if segment=='full' else [.001]):
                for mode in ('whole','selective'):
                    for rate in ([0,.22] if fee==.001 else [.22]):
                        r=simulate_compare(ds[start:],p[start:],raw[start:],fx[start:],mode,fee,rate)
                        tag=f'{proxy}_{segment}_{mode}_{fee}_{rate}'
                        paths[tag]=r.pop('trace');ledgers[tag]=r.pop('ledger')
                        if mode=='whole' and fee==.001:
                            old=simulate(ds[start:],p[start:],raw[start:],fx[start:],np.tile(W,(len(ds)-start,1)),'base',rate)
                            for key in ('held','liquidated','mdd'):assert abs(r[key]-old[key])<=.000501,(tag,key,r[key],old[key])
                            assert r['orders']==old['trades'];regressions+=1
                        results.append(dict(proxy=proxy,segment=segment,start=str(ds[start]),end=str(ds[-1]),mode=mode,fee=fee,tax_rate=rate,**r))
                        if rate==.22 and fee==.001:print(proxy,segment,mode,*(round(r[k],3) for k in ['held','liquidated','mdd','average_cash']),r['orders'],r['shortfall_events'])
    (root/'selective_results.json').write_text(json.dumps(results,indent=2),encoding='utf8')
    (root/'selective_ledgers.json').write_text(json.dumps(ledgers,indent=2),encoding='utf8')
    (root/'selective_paths.json').write_text(json.dumps(paths),encoding='utf8')
    print('Baseline regressions PASS',regressions,'cases; simulations',len(results),'independent walk-forward windows 0')

if __name__=='__main__':main()
