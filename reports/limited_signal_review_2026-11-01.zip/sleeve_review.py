from tax_core import *
W=np.array([.15,.40,.25,.20])
results=[]
for proxy in ('DVY','VIG'):
    data=get(proxy); ds,p,fx=data
    tar=signals(data,proxy)|more_signals(data,proxy)
    options={'base':tar['base']}
    for name in ('st','ce','squeeze'):
        for portion in (.1,.2):
            options[name+str(portion)]=W+(tar[name]-W)*portion/.5
    # A signal controls 20% of QQQM holdings only = 8% of portfolio.
    qqq=tar['base'].copy();qqq[:,1]=W[1]+(tar['squeeze'][:,1]-W[1])*.4
    options['qqq_squeeze20']=qqq
    closes=[linked(proxy,'SCHD'),linked('QQQ','QQQM'),bars('IEF'),linked('IAU','IAUM')]
    raw=np.array([[c[d][2] for c in closes] for d in ds])
    for seg,a in [('full',0),('later',ds.index(dt.date(2016,10,31))),('actual',ds.index(dt.date(2021,7,1)))]:
        for key,t in options.items():
            res=simulate(ds[a:],p[a:],raw[a:],fx[a:],t[a:],key,.22)
            results.append(dict(proxy=proxy,segment=seg,strategy=key,**res))
            print(proxy,seg,key,*[res[x] for x in ('held','liquidated','mdd','trades')])
(root/'sleeve_results.json').write_text(json.dumps(results,indent=1))

